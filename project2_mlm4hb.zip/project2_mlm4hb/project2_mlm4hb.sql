-- 1. Write a query to create a view named “EmployeesPerCountry” that shows the country_name and the number of employees from that country in a column called “Number of Employees”.
CREATE VIEW EmployeesPerCountry AS 
SELECT c.country_name, COUNT(e.employee_id) AS "Number of Employees"
FROM countries c, locations l, departments d, employees e
WHERE c.country_id = l.country_id
    AND l.location_id = d.location_id
    AND d.department_id = e.department_id
GROUP BY c.country_name;
    -- Query the EmployeesPerCountry to show the number of employees from the United Kingdom
    SELECT *
    FROM EmployeesPerCountry
    WHERE country_name = "United Kingdom";

-- 2. Write a query to create a view named “managers” to display all the managers. 
CREATE VIEW Managers AS
SELECT e.first_name, e.last_name, e.phone_number, e.email, j.job_title, d.department_name
FROM employees e, jobs j, departments d
WHERE e.job_id = j.job_id AND d.department_id = e.department_id
GROUP BY e.first_name, e.last_name, e.phone_number, e.email, j.job_title, d.department_name, e.employee_id
HAVING e.employee_id IN (SELECT manager_id FROM employees GROUP BY manager_id);
    -- Query the managers view to show the number of managers in each department.
    SELECT COUNT(department_name) AS "Number of Managers", department_name
    FROM Managers
    GROUP BY department_name;

-- 3. Write a query to create a view named DependentsByJobTitle to get a count of how many dependents there are for each job title. 
CREATE VIEW DependentsByJobTitle AS
SELECT j.job_title, COUNT(d.dependent_id) AS "Number of Dependents"
FROM jobs j
JOIN employees e ON e.job_id = j.job_id
LEFT JOIN dependents d ON d.employee_id = e.employee_id
GROUP BY job_title;
    -- Query the DependentsByJobTitle view to show the job titles(s) with the largest number of dependents. 
    SELECT *
    FROM DependentsByJobTitle
    GROUP BY job_title
    HAVING `Number of Dependents` = 
        (SELECT MAX(`Number of Dependents`) 
        FROM DependentsByJobTitle);
    

-- 4. Write a query to create a view named DepartmentHiresByYear that calculates the number of employees hired each year in each department, Order results by department name. 
CREATE VIEW DepartmentHiresByYear AS
SELECT YEAR(e.hire_date) AS "Year", d.department_name, COUNT(employee_id)
FROM departments d, employees e
WHERE d.department_id = e.department_id
GROUP BY department_name, `Year`
ORDER BY department_name ASC;
    -- Query the DepartmentHiresByYear view to show department hires in 1998. 
    SELECT *
    FROM DepartmentHiresByYear
    WHERE `Year` = 1998;

    SELECT *
    FROM DepartmentHiresByYear
    ORDER BY `Year` ASC;

-- 5. Write a query to create a view named “AvgSalaryByJobTitle” to calculate the average salary for each job title. 
CREATE VIEW AvgSalaryByJobTitle AS
SELECT j.job_title, CONCAT('$', FORMAT(AVG(e.salary), 'N1')) AS "Average Salary", COUNT(e.employee_id) AS "Number of Employees"
FROM employees e
LEFT JOIN jobs j ON e.job_id = j.job_id
GROUP BY job_title;
    -- Query the AvgSalaryByJobTitle view to show the average salary for the Programmers.
    SELECT *
    FROM AvgSalaryByJobTitle
    WHERE job_title = "Programmer";

-- 6. Write a query to create a view named “AvgSalaryByDepartment” to calculate average salaries for each department. 
CREATE VIEW AvgSalaryByDepartment AS
SELECT d.department_name, AVG(e.salary)AS "Average Salary", COUNT(e.employee_id) AS "Number of Employees"
FROM employees e
LEFT JOIN departments d ON d.department_id = e.department_id
GROUP BY department_name;
    -- Query the AvgSalaryByDepartment view to show the department name and average salary for the department with the lowest average salary.
    SELECT *
    FROM AvgSalaryByDepartment
    ORDER BY `Average Salary` ASC
    LIMIT 1;

-- 7. Write a query to create a view named “EmployeeDependents” that calculates the number of dependents each employees has.
CREATE VIEW EmployeeDependents AS
SELECT CONCAT(e.first_name, ' ', e.last_name) AS "Employee Name", e.email, e.phone_number, COUNT(d.dependent_id) AS "Number of Dependents"
FROM employees e
LEFT JOIN dependents d ON d.employee_id = e.employee_id
GROUP BY `Employee Name`, e.email, e.phone_number;
    -- Query the EmployeeDependents view to show employees with no children". Show employee name (first, last), email, phone number, and number of dependents.
    SELECT *
    FROM EmployeeDependents
    WHERE `Number of Dependents` = 0;

-- 8. Write a query to create a view named “CountryLocation” that calculates the number of locations in each region. 
CREATE VIEW “CountryLocation” AS
SELECT r.region_name, COUNT(l.location_id) AS "Number of Locations in Region"
FROM locations l
JOIN countries c ON c.country_id = l.country_id
RIGHT JOIN regions r ON r.region_id = c.region_id
GROUP BY region_name;
    -- Query the LocationByRegion view to show regions with no locations". Show region name and number of locations.
    SELECT * 
    FROM “CountryLocation”
    WHERE `Number of Locations in Region` = 0;



import mysql.connector

#query 1
def get_uk_employees(mycursor):
    sql_query = "SELECT * FROM EmployeesPerCountry WHERE country_name = 'United Kingdom';"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nNumber of Employees in the United Kingdom: {record[1]}" + '\033[0m')
    return

#query 2
def get_num_managers(mycursor):
    sql_query = "SELECT COUNT(department_name) AS 'Number of Managers', department_name FROM Managers GROUP BY department_name;"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()

    for record in query_result:
        print("\033[1m" + f"\nNumber of Managers: {record[0]}\nDepartment: {record[1]}\n" + '\033[0m')
    return

#query 3
def get_max_dependents(mycursor):
    sql_query = "SELECT * FROM DependentsByJobTitle GROUP BY job_title HAVING `Number of Dependents` = (SELECT MAX(`Number of Dependents`) FROM DependentsByJobTitle);"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nJob Title: {record[0]}\nNumber of Dependents: {record[1]}\n" + '\033[0m')
    return

#query 4
def get_hires_by_year(mycursor):
    sql_query = "SELECT * FROM DepartmentHiresByYear WHERE `Year` = 1998;"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nDepartment: {record[1]}\nNumber of Employees Hired in 1998: {record[2]}\n" + '\033[0m')
    return

#query 5
def get_avg_prog_sal(mycursor):
    sql_query = "SELECT * FROM AvgSalaryByJobTitle WHERE job_title = 'Programmer';"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nAverage Salary for Programmers: {record[1]}\nNumber of Programmers: {record[2]}\n" + '\033[0m')
    return

#query 6
def get_depa_sal_low(mycursor):
    sql_query = "SELECT * FROM AvgSalaryByDepartment ORDER BY `Average Salary` ASC LIMIT 1;"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nDepartment Name: {record[0]}\nAverage Salary: ${record[1]}\nNumber of Employees in Department: {record[2]}\n" + '\033[0m')
    return

#query 7
def get_emp_depe(mycursor):
    sql_query = "SELECT * FROM EmployeeDependents WHERE `Number of Dependents` = 0;"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nEmployee Name: {record[0]}\nEmail: ${record[1]}\nPhone Number: {record[2]}\n" + '\033[0m')
    return

#query 8
def get_noloc_regions(mycursor):
    sql_query = "SELECT * FROM CountryLocation WHERE `Number of Locations in Region` = 0;"
    mycursor.execute(sql_query)
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\nRegion Name: {record[0]}" + '\033[0m')
    return

def print_menu():
    print("\nChoose an option")
    print("1. Show the Number of Employees Based in the United Kingdom")
    print("2. Show the Number of Managers per Department")
    print("3. List the Job Titles with the Largest Number of Dependents")
    print("4. List the Department Hires in 1998")
    print("5. Show the Average Salary for Programmers")
    print("6. Show the Department with the Lowest Average Salary")
    print("7. Show Employees with No Dependents")
    print("8. Show the Regions with No Locations")
    print("9. Exit Application")
    return

def get_user_choice():
    print_menu()
    try:
        choice = int(input("\nEnter Choice: "))
        return choice
    except ValueError:
        print("Invalid entry type.")

def main():
    while(True):
        try:
                mydb = mysql.connector.connect(
                    host="mysql-container",
                    user="root",
                    passwd="root",
                    database="project2"
                )
                print("Successfully connected to the database!")
        except Exception as err:
            print(f"Error Occured: {err}\nExiting program...")
            continue
        mycursor = mydb.cursor()

        while(True):
            user_choice = get_user_choice()
            if(user_choice == 1):
                get_uk_employees(mycursor)
            elif(user_choice == 2):
                get_num_managers(mycursor)
            elif(user_choice == 3):
                get_max_dependents(mycursor)
            elif(user_choice == 4):
                get_hires_by_year(mycursor)
            elif(user_choice == 5):
                get_avg_prog_sal(mycursor)
            elif(user_choice == 6):
                get_depa_sal_low(mycursor)
            elif(user_choice == 7):
                get_emp_depe(mycursor)
            elif(user_choice == 8):
                get_noloc_regions(mycursor)
            elif(user_choice == 9):
                print("Exiting program...Bye!")
                quit()
            else:
                print("Please enter an integer 1-9.")
main()


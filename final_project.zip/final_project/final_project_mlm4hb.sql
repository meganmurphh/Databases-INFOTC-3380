CREATE VIEW EmployeesPerCountry AS 
SELECT c.country_name, COUNT(e.employee_id) AS "Number of Employees"
FROM countries c, locations l, departments d, employees e
WHERE c.country_id = l.country_id
    AND l.location_id = d.location_id
    AND d.department_id = e.department_id
GROUP BY c.country_name;

CREATE VIEW Managers AS
SELECT e.first_name, e.last_name, e.phone_number, e.email, j.job_title, d.department_name
FROM employees e, jobs j, departments d
WHERE e.job_id = j.job_id AND d.department_id = e.department_id
GROUP BY e.first_name, e.last_name, e.phone_number, e.email, j.job_title, d.department_name, e.employee_id
HAVING e.employee_id IN (SELECT manager_id FROM employees GROUP BY manager_id);

CREATE VIEW DependentsByJobTitle AS
SELECT j.job_title, COUNT(d.dependent_id) AS "Number of Dependents"
FROM jobs j
JOIN employees e ON e.job_id = j.job_id
LEFT JOIN dependents d ON d.employee_id = e.employee_id
GROUP BY job_title;

CREATE VIEW DepartmentHiresByYear AS
SELECT YEAR(e.hire_date) AS "Year", d.department_name, COUNT(employee_id)
FROM departments d, employees e
WHERE d.department_id = e.department_id
GROUP BY department_name, `Year`
ORDER BY department_name ASC;

CREATE VIEW AvgSalaryByJobTitle AS
SELECT j.job_title, CONCAT('$', FORMAT(AVG(e.salary), 'N1')) AS "Average Salary", COUNT(e.employee_id) AS "Number of Employees"
FROM employees e
LEFT JOIN jobs j ON e.job_id = j.job_id
GROUP BY job_title;

CREATE VIEW AvgSalaryByDepartment AS
SELECT d.department_name, AVG(e.salary)AS "Average Salary", COUNT(e.employee_id) AS "Number of Employees"
FROM employees e
LEFT JOIN departments d ON d.department_id = e.department_id
GROUP BY department_name;

CREATE VIEW EmployeeDependents AS
SELECT CONCAT(e.first_name, ' ', e.last_name) AS "Employee Name", e.email, e.phone_number, COUNT(d.dependent_id) AS "Number of Dependents"
FROM employees e
LEFT JOIN dependents d ON d.employee_id = e.employee_id
GROUP BY `Employee Name`, e.email, e.phone_number;

CREATE VIEW “CountryLocation” AS
SELECT r.region_name, COUNT(l.location_id) AS "Number of Locations in Region"
FROM locations l
JOIN countries c ON c.country_id = l.country_id
RIGHT JOIN regions r ON r.region_id = c.region_id
GROUP BY region_name;
import mysql.connector

##GET
#1
def get_emp_count(mycursor, choice):
    sql_query = "SELECT * FROM EmployeesPerCountry WHERE country_name = %s;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\n{record[0]}: {record[1]} employees" + '\033[0m')

#2
def get_num_managers(mycursor, choice):
    sql_query = "SELECT COUNT(department_name) AS 'Number of Managers', department_name FROM Managers WHERE department_name = %s GROUP BY department_name;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\n{record[1]} Department: {record[0]} managers" + '\033[0m') 

#3
def get_depend_data(mycursor, choice):
    sql_query = "SELECT * FROM DependentsByJobTitle WHERE job_title = %s;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\n{record[0]}: {record[1]} dependents" + '\033[0m')

#4
def get_hires(mycursor, choice):
    sql_query = "SELECT * FROM DepartmentHiresByYear WHERE `Year` = %s;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"{choice} {record[1]}: {record[2]} employees hired" + '\033[0m')

#5
def get_avg_sal_jt(mycursor, choice):
    sql_query = "SELECT * FROM AvgSalaryByJobTitle WHERE job_title = %s;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"\n{record[0]}: {record[1]}" + '\033[0m')

#6
def get_avg_sal_dep(mycursor, choice):
    sql_query = "SELECT * FROM AvgSalaryByDepartment WHERE department_name = %s;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"{record[0]}: " + "${0:.2f}".format(record[1]) + '\033[0m')

#7
def get_emp_depe(mycursor, choice):
        sql_query = "SELECT * FROM EmployeeDependents WHERE `Number of Dependents` > 0 AND `Employee Name` = %s;"
        mycursor.execute(sql_query, (choice,))
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"\n{record[0]}: {record[3]} dependents" + '\033[0m')

#8
def get_loc_reg(mycursor, choice):
    sql_query = "SELECT * FROM CountryLocation WHERE region_name = %s;"
    mycursor.execute(sql_query, (choice,))
    query_result = mycursor.fetchall()
    for record in query_result:
        print("\033[1m" + f"{record[0]}: {record[1]} locations." + '\033[0m')

##POST
#1
def post_emp_count(mycursor): 
    print("\033[1m" + "\n---------------Number of Employees Per Country---------------" + '\033[0m')
    choice = input("Enter region name for specific region or (All) to view all regions: ")
    if(choice == "Canada"):
        get_emp_count(mycursor, choice)
    elif(choice == "Germany"):
        get_emp_count(mycursor, choice)
    elif(choice == "United Kingdom"):
        get_emp_count(mycursor, choice)
    elif(choice == "United States of America"):
        get_emp_count(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT * FROM EmployeesPerCountry"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"\n{record[0]}: {record[1]} employees" + '\033[0m')
    else:
        print("\033[1m" + f"There are no employees based in {choice}." + "\033[0m")

#2       
def post_num_managers(mycursor): 
    print("\033[1m" + "\n---------------Number of Managers Per Department---------------" + '\033[0m')
    choice = input("Enter department name for specific department or (All) to view all departments: ")
    if(choice == "Marketing"):
        get_num_managers(mycursor, choice)
    elif(choice == "Purchasing"):
        get_num_managers(mycursor, choice)
    elif(choice == "Shipping"):
        get_num_managers(mycursor, choice)
    elif(choice == "IT"):
        get_num_managers(mycursor, choice)
    elif(choice == "Executive"):
        get_num_managers(mycursor, choice)
    elif(choice == "Finance"):
        get_num_managers(mycursor, choice)
    elif(choice == "Accounting"):
        get_num_managers(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT COUNT(department_name) AS 'Number of Managers', department_name FROM Managers GROUP BY department_name;"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"\n{record[1]} Department: {record[0]} managers" + '\033[0m')
    else:
        print("\033[1m" + f"There is no {choice} department." + "\033[0m")

#3
def post_depend_data(mycursor): 
    print("\033[1m" + "\n---------------Number of Dependents Per Job Title---------------" + '\033[0m')
    choice = input("Enter job title or (All) to view all dependents by job title: ")
    if(choice == "Public Accountant"):
        get_depend_data(mycursor, choice)
    elif(choice == "Accounting Manager"):
        get_depend_data(mycursor, choice)
    elif(choice == "Administration Assistant"):
        get_depend_data(mycursor, choice)
    elif(choice == "President"):
        get_depend_data(mycursor, choice)
    elif(choice == "Administration Vice President"):
        get_depend_data(mycursor, choice)
    elif(choice == "Accountant"):
        get_depend_data(mycursor, choice)
    elif(choice == "Finance Manager"):
        get_depend_data(mycursor, choice)
    elif(choice == "Human Resources Representative"):
        get_depend_data(mycursor, choice)
    elif(choice == "Programmer"):
        get_depend_data(mycursor, choice)
    elif(choice == "Marketing Manager"):
        get_depend_data(mycursor, choice)
    elif(choice == "Marketing Representative"):
        get_depend_data(mycursor, choice)
    elif(choice == "Public Relations Representative"):
        get_depend_data(mycursor, choice)
    elif(choice == "Purchasing Clerk"):
        get_depend_data(mycursor, choice)
    elif(choice == "Purchasing Manager"):
        get_depend_data(mycursor, choice)
    elif(choice == "Sales Manager"):
        get_depend_data(mycursor, choice)
    elif(choice == "Sales Representative"):
        get_depend_data(mycursor, choice)
    elif(choice == "Shipping Clerk"):
        get_depend_data(mycursor, choice)
    elif(choice == "Stock Clerk"):
        get_depend_data(mycursor, choice)
    elif(choice == "Stock Manager"):
        get_depend_data(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT * FROM DependentsByJobTitle;"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"\n{record[0]}: {record[1]} dependents" + '\033[0m')
    else:
        print("\033[1m" + f"There is no such job title as {choice}." + "\033[0m")

#4
def post_hires(mycursor): 
    print("\033[1m" + "\n---------------Hires by Year and Department---------------" + '\033[0m')
    choice = input("Enter year or (All) to view hiring data for all years in all departments: ")
    if(choice == "1987"):
        get_hires(mycursor, choice)
    elif(choice == "1989"):
        get_hires(mycursor, choice)
    elif(choice == "1990"):
        get_hires(mycursor, choice)
    elif(choice == "1991"):
        get_hires(mycursor, choice)
    elif(choice == "1993"):
        get_hires(mycursor, choice)
    elif(choice == "1994"):
        get_hires(mycursor, choice)
    elif(choice == "1995"):
        get_hires(mycursor, choice)
    elif(choice == "1996"):
        get_hires(mycursor, choice)
    elif(choice == "1997"):
        get_hires(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT * FROM DepartmentHiresByYear;"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"{record[0]} {record[1]}: {record[2]} employees hired" + '\033[0m')
    else:
        print("\033[1m" + f"There is no hire data for year {choice}." + "\033[0m")

#5
def post_avg_sal_jt(mycursor): 
    print("\033[1m" + "\n---------------Average Salary Per Job Title---------------" + '\033[0m')
    choice = input("Enter job title or (All) to view all average salarys for each job title: ")
    if(choice == "President"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Administration Vice President"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Programmer"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Finance Manager"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Accountant"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Purchasing Manager"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Purchasing Clerk"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Stock Manager"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Stock Clerk"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Sales Manager"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Sales Representative"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Shipping Clerk"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Administration Assistant"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Marketing Manager"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Marketing Representative"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Human Resources Representative"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Public Relations Representative"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Accounting Manager"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "Public Accountant"):
        get_avg_sal_jt(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT * FROM AvgSalaryByJobTitle;"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"{record[0]}: {record[1]}" + '\033[0m')
    else:
        print("\033[1m" + f"\nThere is no such job title as {choice}." + "\033[0m")

#6
def post_avg_sal_dep(mycursor): 
    print("\033[1m" + "\n---------------Average Salary Per Department---------------" + '\033[0m')
    choice = input("Enter department or (All) to view all average salarys for each department: ")
    if(choice == "Executive"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "IT"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Finance"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Purchasing"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Shipping"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Sales"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Administration"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Marketing"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Human Resources"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Public Relations"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "Accounting"):
        get_avg_sal_dep(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT * FROM AvgSalaryByDepartment;"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"{record[0]}: " + "${0:.2f}".format(record[1]) + '\033[0m')
    else:
        print("\033[1m" + f"There is no {choice} department." + "\033[0m")

#7
def post_emp_depe(mycursor): 
    print("\033[1m" + "\n---------------Employees with Dependents---------------" + '\033[0m')
    choice = input("Enter employee first and last name or (All) to view dependent data for all employees: ")
    if(choice == "Steven King"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Neena Kochhar"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Lex De Haan"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Alexander Hunold"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Bruce Ernst"):
        get_emp_depe(mycursor, choice)
    elif(choice == "David Austin"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Valli Pataballa"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Diana Lorentz"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Nancy Greenberg"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Daniel Faviet"):
        get_emp_depe(mycursor, choice)
    elif(choice == "John Chen"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Ismael Sciarra"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Jose Manuel Urman"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Luis Popp"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Den Raphaely"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Alexander Khoo"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Shelli Baida"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Sigal Tobias"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Guy Himuro"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Karen Colmenares"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Matthew Weiss"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Adam Fripp"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Payam Kaufling"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Shanta Vollman"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Irene Mikkilinen"):
        get_emp_depe(mycursor, choice)
    elif(choice == "John Russell"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Karen Partners"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Jonathon Taylor"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Jack Livingston"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Kimberely Grant"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Charles Johnson"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Sarah Bell"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Britney Everett"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Jennifer Whalen"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Michael Hartstein"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Pat Fay"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Susan Mavris"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Hermann Baer"):
        get_emp_depe(mycursor, choice)
    elif(choice == "Shelley Higgins"):
        get_emp_depe(mycursor, choice)
    elif(choice == "William Geitz"):
        get_emp_depe(mycursor, choice)
    elif(choice == "All"):
        sql_query = "SELECT * FROM EmployeeDependents;"
        mycursor.execute(sql_query)
        query_result = mycursor.fetchall()
        for record in query_result:
            print("\033[1m" + f"{record[0]}: {record[3]} dependents" + '\033[0m')
    else:
        print(f"There is no record for employee {choice}")

#8
def post_loc_reg(mycursor):
        print("\033[1m" + "\n---------------Region Locations---------------" + '\033[0m')
        choice = input("Enter region name or (All) to view location data for all regions: ")
        if(choice == "Americas"):
            get_loc_reg(mycursor, choice)
        elif(choice == "Europe"):
            get_loc_reg(mycursor, choice)
        elif(choice == "Asia"):
            get_loc_reg(mycursor, choice)
        elif(choice == "Middle East and Africa"):
            get_loc_reg(mycursor, choice)
        elif(choice == "All"):
            sql_query = "SELECT * FROM CountryLocation;"
            mycursor.execute(sql_query)
            query_result = mycursor.fetchall()
            for record in query_result:
                print("\033[1m" + f"{record[0]}: {record[1]} locations." + '\033[0m')
        else:
            print("\033[1m" + f"There is no data for {choice} region" + '\033[0m')

##ADDING
def add_dep(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Add a Dependent---------------" + '\033[0m')
        choice1 = input("Enter dependent first name: ")
        choice2 = input("Enter dependent last name: ")
        choice3 = input("Enter dependent relationship: ")
        choice4 = input("Enter employee ID: ")
        try:
            choice4 = int(choice4)
        except ValueError:
            print("\nInvalid entry type detected. Please enter an integer.")
        else:
            insert_query = "INSERT INTO dependents(first_name, last_name, relationship, employee_id) VALUES('%s', '%s', '%s', '%d')" % (choice1, choice2, choice3, choice4)
            try:
                mycursor.execute(insert_query)
                mydb.commit()
                print(f"\nSuccess: {mycursor.rowcount} dependent added")
            except mysql.connector.Error as e:
                print(f"\nInsert Failed.\nError: {e.msg}")
            break

def add_job(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Add a Job---------------" + '\033[0m')
        choice1 = input("Enter a new job title: ")
        choice2 = input("Enter minimum salary: ")
        choice3 = input("Enter maximum salary: ")
        try:
            choice2 = int(choice2)
            choice3 = int(choice3)
            if(choice2 > choice3):
                raise ValueError
            elif(choice2 | choice3 == 0):
                raise ZeroDivisionError
        except ValueError:
            print("\nError: Invalid entry. Maximum salary must be greater than minimum salary.")
        except ZeroDivisionError:
            print("\nError: Invalid entry type. Salary must be greater than 0.")
        else:
            insert_query = "INSERT INTO jobs(job_title, min_salary, max_salary) VALUES('%s', %d, %d)" % (choice1, choice2, choice3)
            try:
                mycursor.execute(insert_query)
                mydb.commit()
                print(f"\nSuccess: {mycursor.rowcount} job added")
            except mysql.connector.Error as e:
                print(f"\nInsert Failed.\nError: {e.msg}")
            break

##DELETING
def del_dep(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Delete a Dependent---------------" + '\033[0m')
        choice = input("Enter dependent ID to be deleted: ")
        try:
            choice = int(choice)
            if(choice is None):
                raise ValueError
        except ValueError:
            print("\nInvalid entry type. Please enter an integer.")
        else:
            delete_query = "DELETE FROM dependents WHERE dependent_id = %s;"
            try:
                mycursor.execute(delete_query, (choice,))
                mydb.commit()
                print(f"\nSuccess: Employee with ID {choice} was deleted.")
            except mysql.connector.Error as e:
                print(f"\nDeletion Failed.\nError: {e.msg}")
            break

def del_emp(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Delete an Employee---------------" + '\033[0m')
        choice = input("Enter employee ID to be deleted: ")
        try:
            choice = int(choice)
            if(choice is None):
                raise ValueError
        except ValueError:
            print("\nInvalid entry type. Please enter an integer.")
        else:
            delete_query = "DELETE FROM employees WHERE employee_id = %s;"
            try:
                mycursor.execute(delete_query, (choice,))
                mydb.commit()
                print(f"\nSuccess: Employee with ID {choice} was deleted.")
            except mysql.connector.Error as e:
                print(f"\nDeletion Failed.\nError: {e.msg}")
            break

##UPDATING

def upd_empfn(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Update Employee First Name---------------" + '\033[0m')
        choice1 = input("Enter employee ID to be updated: ")
        choice2 = input("Enter employee's new first name: ")
        try:
            choice1 = int(choice1)
            if(choice2 == ''):
                raise ZeroDivisionError
        except ValueError:
            print("\nInvalid entry type. Please enter an integer.")
        except ZeroDivisionError:
            print("\nInvalid entry type. First name cannot be null.")
        else:
            upd_query = "UPDATE employees SET `first_name` = %s WHERE employee_id = %s;"
            try:
                mycursor.execute(upd_query, (choice2, choice1))
                mydb.commit()
                print(f"\nSuccess: Employee with ID {choice1} was updated.")
            except mysql.connector.Error as e:
                print(f"\nDeletion Failed.\nError: {e.msg}")
            break

def upd_empln(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Update Employee Last Name---------------" + '\033[0m')
        choice1 = input("Enter employee ID to be updated: ")
        choice2 = input("Enter employee's new last name: ")
        try:
            choice1 = int(choice1)
            if(choice2 == ''):
                raise ZeroDivisionError
        except ValueError:
            print("\nInvalid entry type. Please enter an integer.")
        except ZeroDivisionError:
            print("\nInvalid entry type. Last name cannot be null.")
        else:
            upd_query = "UPDATE employees SET `last_name` = %s WHERE employee_id = %s;"
            try:
                mycursor.execute(upd_query, (choice2, choice1))
                mydb.commit()
                print(f"\nSuccess: Employee with ID {choice1} was updated.")
            except mysql.connector.Error as e:
                print(f"\nDeletion Failed.\nError: {e.msg}")
            break

def upd_min_sal(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Update Job Minimum Salary---------------" + '\033[0m')
        choice1 = input("Enter job ID to be updated: ")
        choice2 = input("Enter job's new minimum salary: ")
        try:
            choice1 = int(choice1)
            choice2 = int(choice2)
            if (choice2 == 0):
                raise ValueError("Salary must be greater than 0.")
        except ValueError:
            print("\nError: Invalid entry.")
        else:
            upd_query = "UPDATE jobs SET `min_salary` = %s WHERE job_id = %s;"
            try:
                mycursor.execute(upd_query, (choice2, choice1))
                mydb.commit()
                print(f"\nSuccess: Job with ID {choice1}'s minimum salary was updated.")
            except mysql.connector.Error as e:
                print(f"\nUpdate Failed.\nError: {e.msg}")
            break

def upd_max_sal(mycursor, mydb):
    while(True):
        print("\033[1m" + "\n---------------Update Job Maximum Salary---------------" + '\033[0m')
        choice1 = input("Enter job ID to be updated: ")
        choice2 = input("Enter job's new maximum salary: ")
        try:
            choice1 = int(choice1)
            choice2 = int(choice2)
            if (choice2 == 0):
                raise ValueError("Salary must be greater than 0.")
        except ValueError:
            print("\nError: Invalid entry.")
        else:
            upd_query = "UPDATE jobs SET `max_salary` = %s WHERE job_id = %s;"
            try:
                mycursor.execute(upd_query, (choice2, choice1))
                mydb.commit()
                print(f"\nSuccess: Job with ID {choice1}'s maximum salary was updated.")
            except mysql.connector.Error as e:
                print(f"\nUpdate Failed.\nError: {e.msg}")
            break


def print_menu():
    print("\nChoose an option:")
    print("\033[1m" + "***************VIEW DATA***************" + '\033[0m')
    print("1. View employee count data per country")
    print("2. View manager count by department")
    print("3. View dependent data per job title")
    print("4. View hiring data by year and department")
    print("5. View average salary data by job title")
    print("6. View average salary data by department")
    print("7. View dependent data by employee")
    print("8. View location data by region")
    print("\033[1m" + "\n***************ADD DATA***************" + '\033[0m')
    print("9. Add a dependent")
    print("10. Add a job")
    print("\033[1m" + "\n***************DELETE DATA***************" + '\033[0m')
    print("11. Delete an employee")
    print("12. Delete a dependent")
    print("\033[1m" + "\n***************UPDATE DATA***************" + '\033[0m')
    print("13. Update employee first name")
    print("14. Update employee last name")
    print("15. Update job minimum salary")
    print("16. Update job maxium salary")
    print("\033[1m" + "\n***************EXIT***************" + '\033[0m')
    print("17. Exit Application")
    return

def get_user_choice():
    print_menu()
    try:
        choice = int(input("\nEnter Choice: "))
        return choice
    except ValueError:
        print("Invalid entry type.")

def main():
    while(True):
        try:
                mydb = mysql.connector.connect(
                    host="mysql-container",
                    user="root",
                    passwd="root",
                    database="project2"
                )
                print("Successfully connected to the database!")
        except Exception as err:
            print(f"Error Occured: {err}\nExiting program...")
            continue
        mycursor = mydb.cursor()

        while(True):
            user_choice = get_user_choice()
            if(user_choice == 1):
                post_emp_count(mycursor)
            elif(user_choice == 2):
                post_num_managers(mycursor)
            elif(user_choice == 3):
                post_depend_data(mycursor)
            elif(user_choice == 4):
                post_hires(mycursor)
            elif(user_choice == 5):
                post_avg_sal_jt(mycursor)
            elif(user_choice == 6):
                post_avg_sal_dep(mycursor)
            elif(user_choice == 7):
                post_emp_depe(mycursor)
            elif(user_choice == 8):
                post_loc_reg(mycursor)
            elif(user_choice == 9):
                add_dep(mycursor, mydb)
            elif(user_choice == 10):
                add_job(mycursor, mydb)
            elif(user_choice == 11):
                del_emp(mycursor, mydb)
            elif(user_choice == 12):
                del_dep(mycursor, mydb)
            elif(user_choice == 13):
                upd_empfn(mycursor, mydb)
            elif(user_choice == 14):
                upd_empln(mycursor, mydb)
            elif(user_choice == 15):
                upd_min_sal(mycursor, mydb)
            elif(user_choice == 16):
                upd_max_sal(mycursor, mydb)
            elif(user_choice == 17):
                print("Exiting program...Bye!")
                quit()
            else:
                print("Please enter an integer 1-17.")
main()

